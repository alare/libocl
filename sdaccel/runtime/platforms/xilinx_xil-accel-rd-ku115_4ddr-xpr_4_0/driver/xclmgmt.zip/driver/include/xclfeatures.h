/**
 *  Xilinx SDAccel FPGA BIOS definition
 *  Copyright (C) 2016, Xilinx Inc - All rights reserved
 */


//Layout: At address 0xB0000, we will have the FeatureROMHeader that comprises:
//
//1. First have FeatureRomHeader: 152 bytes of information followed by
//2. Then, as a part of FeatureRomHeader we have the PRRegion struct(s).
//      The number of such structs will be same as OCLRegionCount.
//3. After this the freq scaling table is laid out. 
//

//#include <stdint.h>

typedef struct PartialRegion {
    uint16_t clk[4]; 
    uint8_t XPR; //0 : non-xpt, 1: xpr
} PRRegion;

//Each entry represents one row in freq scaling table.
struct FreqScalingTableRow{
    short config0;
    short freq;
    short config2;
};

struct FeatureRomHeader {
    unsigned char EntryPointString[4]; //This is "xlnx"
    uint8_t MajorVersion; //Feature ROM's major version eg 1 
    uint8_t MinorVersion; //minor version eg 2.
    uint32_t VivadoBuildID;        // Vivado Software Build (e.g., 1761098 ). From ./vivado --version
    uint32_t IPBuildID;              // IP Build (e.g., 1759159 from abve)
    uint64_t TimeSinceEpoch; //populate it with linux time(NULL) call.
    unsigned char FPGAPartName[64]; //The hardware FPGA part. Null termninated
    unsigned char VBNVName[64]; // eg : xilinx:xil-accel-rd-ku115:4ddr-xpr:3.4: null terminated
    uint8_t DDRChannelCount; // 4 for TUL
    uint8_t DDRChannelSize; // 4 (in GB)
    uint8_t OCLRegionCount; //Number of OCL regions 
    uint8_t FPGAType; //maps to enum FPGAGeneration
    uint8_t NumFreqTableRows; //Number of rows in freq scaling table.
    PRRegion region[1]; //The PRRegion struct, lay them out one after another totalling OCLRegionCount.
    unsigned char FreqTable[1]; //NumFreqTableRows of FreqScalingTableRow struct
};

