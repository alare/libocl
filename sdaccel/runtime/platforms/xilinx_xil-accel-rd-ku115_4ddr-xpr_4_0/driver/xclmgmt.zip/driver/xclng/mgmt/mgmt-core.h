#ifndef _XCL_MGT_PF_H_
#define _XCL_MGT_PF_H_

#include <linux/cdev.h>
#include <linux/list.h>
#include <linux/signal.h>
#include <linux/init_task.h>
#include <linux/mutex.h>
#include <linux/pci.h>
#include <linux/delay.h>
#include <linux/time.h>
#include <linux/types.h>
#include <asm/io.h>
#include "mgmt-reg.h"
#include "mgmt-ioctl.h"
#include "xclfeatures.h"


#define XCLMGMT_DRIVER_MAJOR 2017
#define XCLMGMT_DRIVER_MINOR 1
#define XCLMGMT_DRIVER_PATCHLEVEL 29

#define XCLMGMT_MINOR_BASE (0)
#define XCLMGMT_MINOR_COUNT (16)

#define DRV_NAME "xclmgmt"

struct xclmgmt_ioc_info;

struct xclmgmt_bitstream_container {
	/* MAGIC_BITSTREAM == 0xBBBBBBBBUL */
	unsigned long magic;
	char *clear_bitstream;
	u32 clear_bitstream_length;
};

// List of processes that are using the mgmt driver
// also saving the task
struct proc_list {

	struct list_head head;
	struct pid 	 *pid;

};

struct xclmgmt_dev {
	/* MAGIC_DEVICE == 0xAAAAAAAA */
	unsigned long magic;
	/* The feature Rom header */
	struct FeatureRomHeader header;
	/* the kernel pci device data structure provided by probe() */
	struct pci_dev *pci_dev;
	struct pci_dev *user_pci_dev;
	int instance;
	void *__iomem bar[XCLMGMT_MAX_BAR];
	resource_size_t bar_map_size[XCLMGMT_MAX_BAR];
	struct xclmgmt_char *user_char_dev;
	struct xclmgmt_bitstream_container stash;
	int axi_gate_frozen;
	u64 feature_id;
	unsigned short ocl_frequency[4];
	u64 unique_id_last_bitstream;
#ifdef AXI_FIREWALL
	u32 err_firewall_status[XCLMGMT_NUM_FIREWALL_IPS];
	u64 err_firewall_time[XCLMGMT_NUM_FIREWALL_IPS];
	struct proc_list proc_list;
	struct mutex proc_mutex;
#endif
	struct task_struct *kthread;
	bool busy;
//	struct mutex ioctl_mutex;
};

struct xclmgmt_char {
	struct xclmgmt_dev *lro;
	struct cdev cdev;
	struct device *sys_device;
	int bar;
};

struct xclmgmt_ocl_clockwiz {
	/* target frequency */
	unsigned short ocl;
	/* config0 register */
	unsigned long config0;
	/* config2 register */
	unsigned short config2;
};

int bitstream_ioctl(struct xclmgmt_dev *lro, const void __user *arg);
int bitstream_ioctl_axlf(struct xclmgmt_dev *lro, const void __user *arg);
int ocl_freqscaling_ioctl(struct xclmgmt_dev *lro, const void __user *arg);
void freezeAXIGate(struct xclmgmt_dev *lro);
void freeAXIGate(struct xclmgmt_dev *lro);
void fill_frequency_info(struct xclmgmt_dev *lro, struct xclmgmt_ioc_info *obj);
void device_info(struct xclmgmt_dev *lro, struct xclmgmt_ioc_info *obj);
long load_boot_firmware(struct xclmgmt_dev *lro);
long ocl_freqscaling(struct xclmgmt_dev *lro, bool force);
long mgmt_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);
int mgmt_load_reset_mini_bitstream(struct xclmgmt_dev *lro);
void fan_controller(const struct xclmgmt_dev *lro);

// Thread.c
void init_health_thread(struct xclmgmt_dev *lro);
void fini_health_thread(const struct xclmgmt_dev *lro);

// utils.c
unsigned compute_unit_busy(struct xclmgmt_dev *lro);
int16_t onchip_temp(uint32_t temp);
unsigned short to_volt(uint32_t volt);
void check_temp_within_range(int16_t temp);
void check_volt_within_range(unsigned short volt);
bool check_axi_firewall( struct xclmgmt_dev *lro);
int pci_fundamental_reset(struct xclmgmt_dev *lro);
/* Note: Use reset_hot_ioctl over pcie fundamental reset.
 * This method is known to work better.
 */
long reset_hot_ioctl(struct xclmgmt_dev *lro);
bool is_ultrascale(const struct xclmgmt_dev *lro);
bool is_ultrascale_plus(const struct xclmgmt_dev *lro);
bool is_XPR(const struct xclmgmt_dev *lro);
void xdma_reset(struct pci_dev *pdev, bool prepare);

// firewall.c
void init_firewall(struct xclmgmt_dev *lro);
void xclmgmt_killall_processes(struct xclmgmt_dev *lro);
void xclmgmt_list_add(struct xclmgmt_dev *lro, struct pid *new_pid);
//struct proc_list *xclmgmt_find_by_pid(struct xclmgmt_dev *lro, struct pid *find_pid);
void xclmgmt_list_remove(struct xclmgmt_dev *lro, struct pid *remove_pid);
void xclmgmt_list_del(struct xclmgmt_dev *lro);

#endif
